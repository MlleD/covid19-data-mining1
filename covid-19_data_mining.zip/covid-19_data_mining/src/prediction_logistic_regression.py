from sklearn.linear_model import LogisticRegression as skLogisticRegression

class LogisticRegression:
    def __init__(self, is_nb_sents_reduced=True):
        maxi = 0
        solver_ = ""
        if is_nb_sents_reduced:
            maxi = 250
            solver_ = "lbfgs"
        else:
            maxi = 60
            solver_ = "sag"
        self.classifier = skLogisticRegression(solver=solver_, max_iter=maxi)

    def train(self, X_train, y_train):
        self.classifier.fit(X_train, y_train)
    
    def predict(self, input):
        return self.classifier.predict(input)

    def get_score(self, X, y):
        return self.classifier.score(X, y)