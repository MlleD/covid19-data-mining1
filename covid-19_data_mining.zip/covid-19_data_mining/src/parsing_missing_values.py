import regex as re

def count_missing_values(filename):
    """Parse le fichier csv et compte les valeurs manquantes par colonne
    Args:
        filename: une string, nom du fichier en entrée
    
    Returns:
        Une liste d'entiers positifs représentant le nombre de valeurs manquantes pour chaque colonne
    """

    regex = '(\d*),(\d*),("[^"]*"|[^,]*),([-\d]*),("[^"]*"(?5)?|[^,]*),([\w ]*)'
    nbMatch = 0
    count_missing_values = [0] * len(regex.split('),('))
    with open(filename, errors="ignore") as f:
        text = f.read()
        for match in re.finditer(regex, text):
            for idx, group in enumerate(match.groups()):
                if group == '':
                    count_missing_values[idx] += 1
    return count_missing_values

if __name__ == "__main__":
    print(count_missing_values("../data/Corona_NLP_train.csv"))