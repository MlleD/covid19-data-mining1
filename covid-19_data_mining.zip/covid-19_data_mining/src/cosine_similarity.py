import math

# similarité de 1 si a = b
# similarité entre 0 à 1 quand tous les coefficients (= term frequencies) de a et b sont positif.
def cosine_similarity (a, b):
    """Calcule la similarité cosinus entre a et b
    Args:
        a: vecteur représentant le mot 1
        b: vecteur représentant le mot 2
    Returns:
        la similarité cosinus entre a et b
    """
    len_a = len(a)
    len_b = len(b)
    numerator = sum([a[i] * b[i] for i in range(len_a)])
    sqrt_a = math.sqrt(sum([a[i] * a[i] for i in range(len_a)]))
    sqrt_b = math.sqrt(sum([b[i] * b[i] for i in range(len_b)]))
    denominator = sqrt_a * sqrt_b 
    return numerator/denominator    
