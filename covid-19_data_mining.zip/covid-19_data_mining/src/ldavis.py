from pyLDAvis import sklearn as sklearn_lda
import pickle
import pyLDAvis
import os

def do_LDA_visualisation(lda, count_data, vectorizer, number_topics):
    LDAvis_filename = './ldavis_' + str(number_topics)
    LDAvis_data_filepath = os.path.join(LDAvis_filename)
    LDAvis_prepared = sklearn_lda.prepare(lda, count_data, vectorizer, mds='mmds')
    with open(LDAvis_data_filepath, 'wb') as f:
            pickle.dump(LDAvis_prepared, f)

    # charge les données pré-préparées pyLDAvis depuis le disque
    with open(LDAvis_data_filepath, 'rb') as f:
        LDAvis_prepared = pickle.load(f)
        
    pyLDAvis.save_html(LDAvis_prepared, LDAvis_filename +'.html')
