import regex as r
import cst

def parse_datafile(filename):
    """Parse le fichier csv et renvoie les données sous forme d'une liste de listes
    Args:
        filename: une string, nom du fichier en entrée
    
    Returns:
        Une liste contenant à chaque index une liste de N données
    """

    regex = '(\d*),(\d*),("[^"]*"|[^,]*),([-\d]*),("[^"]*"(?5)?|[^,]*),([\w ]*)'
    data = [[] for _ in range(len(regex.split('),(')))]
    with open(filename, errors="ignore") as f:
        text = f.read()
        for match in r.finditer(regex, text):
            for idx, group in enumerate(match.groups()):
                data[idx].append(group)
    return data

if __name__ == "__main__":
    print(parse_datafile(cst.TRAIN))