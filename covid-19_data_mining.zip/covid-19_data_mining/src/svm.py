import cst 
from sklearn.svm import SVC
import cleaning_text as cleaner 
from vectorizing_text import Vectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.svm import SVC


def svm_classify():
     X = cleaner.clean_text(cst.TRAIN)
     print (X)
     y = cleaner.read_column(cst.TRAIN, 5)
     vectorizer = Vectorizer(X)
     matrix = vectorizer.get_score_matrix()
     X_train, X_test, y_train, y_test = train_test_split(matrix, y, test_size = 0.30)
     svclassifier = SVC(kernel='linear')
     svclassifier.fit(X_train, y_train)
     y_predicted = svclassifier.predict(X_test)
     print(confusion_matrix(y_test,y_predicted))
     print(classification_report(y_test,y_predicted))

if __name__ == "__main__":
     svm_classify()

