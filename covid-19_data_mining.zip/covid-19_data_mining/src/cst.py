TRAIN = '../data/Corona_NLP_train.csv'
TEST = '../data/Corona_NLP_test.csv'
TRAIN1 = '../data/TRAIN.csv'
TEST1 = '../data/TEST.csv'
DIC ='../data/britannicDict.txt'
LittleTRAIN = '../data/Littletrain.csv'

