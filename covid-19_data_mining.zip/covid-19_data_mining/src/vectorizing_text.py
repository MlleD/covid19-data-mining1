from sklearn.feature_extraction.text import TfidfVectorizer

class Vectorizer:
    def __init__(self, corpus):
        """Initialise le vectorizer. Crée la matrice TF-IDF à partir du corpus.
        Args:
            corpus: corpus de textes à vectoriser
        """
        self.vectorizer = TfidfVectorizer()
        self.matrix = self.vectorizer.fit_transform(corpus)
    
    def get_dictionary(self):
        """Récupère le dictionnaire des mots du corpus sous forme de liste
        """
        return self.vectorizer.get_feature_names()
    
    def get_score_matrix(self):
        """Récupère la matrice de score TF-IDF
        """
        return self.matrix
    
    def get_vectorizer(self):
        return self.vectorizer

    def fit_transform_train(self, train_data):
        return self.vectorizer.fit_transform(train_data)
    
    def transform_test(self, test_data):
        return self.vectorizer.transform(test_data)

import cleaning_text as text_cleaner
import cst
if __name__ == "__main__":
    corpus = text_cleaner.clean_text(cst.TRAIN)
    vectorizer = Vectorizer(corpus)
    print(vectorizer.get_dictionary())
    matrix = vectorizer.get_score_matrix()
    print(matrix.shape) # (nombre de tweets, nombre de mots)
    print(matrix.todense()) # affiche tous les éléments, y compris les éléments nuls
    print(matrix) # affiche les éléments non nuls
    print(matrix.nonzero()) # affiche les éléments non nuls
    nb_nonzero = matrix.count_nonzero()
    print(nb_nonzero) # affiche le nombre d'éléments non nuls sous forme d'un array
    print(100 * nb_nonzero / (matrix.shape[0] * matrix.shape[1])) # affiche le % d'éléments non nuls
